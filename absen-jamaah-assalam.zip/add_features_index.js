const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

// 1. Add "Export CSV" button to Leaderboard tab
const exportBtnHtml = `
                <div class="flex-row justify-between align-center mb-4">
                    <h3 style="margin: 0;">Peringkat Jamaah Paling Istiqamah</h3>
                    <button id="btn-export-csv" class="btn btn-primary btn-sm admin-only">
                        <i data-lucide="download"></i> Download CSV
                    </button>
                </div>
`;
html = html.replace('<!-- Podiums for Top 3 Streaks -->', exportBtnHtml + '                <!-- Podiums for Top 3 Streaks -->');

// 2. Add "Jadwal Pengajian" to sidebar
const scheduleNavHtml = `
                <button class="nav-item" data-tab="schedule" id="nav-schedule">
                    <i data-lucide="calendar"></i>
                    <span>Jadwal Pengajian</span>
                </button>`;
html = html.replace('                <button class="nav-item" data-tab="settings" id="nav-settings">', scheduleNavHtml + '\n                <button class="nav-item" data-tab="settings" id="nav-settings">');

// 3. Add Tab Content for "Jadwal Pengajian"
// Insert after leaderboard section
const scheduleTabHtml = `
            <!-- TAB: Jadwal Pengajian -->
            <section id="tab-schedule" class="tab-panel">
                <div class="flex-row justify-between align-center mb-4">
                    <h2 class="section-title" style="margin: 0;">Jadwal Pengajian</h2>
                    <button id="btn-add-schedule" class="btn btn-primary admin-only">
                        <i data-lucide="plus"></i> Tambah Jadwal
                    </button>
                </div>
                
                <div id="schedule-list" class="schedule-grid">
                    <!-- Schedule cards will be rendered here -->
                </div>
            </section>
`;
// find where leaderboard section ends
const leaderboardEnd = '</section>\n\n            <!-- TAB 5: Settings -->';
html = html.replace(leaderboardEnd, '</section>\n\n' + scheduleTabHtml + '\n            <!-- TAB 5: Settings -->');

// 4. Add Modal for Schedule Form
const scheduleModalHtml = `
    <!-- Schedule Modal -->
    <div id="schedule-modal" class="modal-overlay">
        <div class="modal-card">
            <div class="modal-header">
                <h3 id="schedule-modal-title">Tambah Jadwal Baru</h3>
                <button class="btn-icon" id="btn-close-schedule-modal">
                    <i data-lucide="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <form id="form-schedule">
                    <input type="hidden" id="schedule-id">
                    <div class="form-group-vertical">
                        <label for="schedule-date">Tanggal</label>
                        <input type="date" id="schedule-date" class="form-input" required>
                    </div>
                    <div class="form-group-vertical">
                        <label for="schedule-time">Waktu / Jam</label>
                        <input type="time" id="schedule-time" class="form-input" required>
                    </div>
                    <div class="form-group-vertical">
                        <label for="schedule-teacher">Nama Guru / Ustadz</label>
                        <input type="text" id="schedule-teacher" class="form-input" placeholder="Contoh: Ustadz Fulan" required>
                    </div>
                    <div class="form-group-vertical">
                        <label>Materi Kajian (Maks 3)</label>
                        <input type="text" id="schedule-materi-1" class="form-input mb-2" placeholder="1. Materi Pertama" required>
                        <input type="text" id="schedule-materi-2" class="form-input mb-2" placeholder="2. Materi Kedua (Opsional)">
                        <input type="text" id="schedule-materi-3" class="form-input" placeholder="3. Materi Ketiga (Opsional)">
                    </div>
                    <div class="modal-actions mt-4">
                        <button type="button" class="btn btn-outline" id="btn-cancel-schedule">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Jadwal</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
`;
// insert before `<script src="supabase-client.js">`
html = html.replace('    <!-- Supabase SDK & Client -->', scheduleModalHtml + '\n    <!-- Supabase SDK & Client -->');

fs.writeFileSync('index.html', html);
console.log('index.html updated successfully.');
