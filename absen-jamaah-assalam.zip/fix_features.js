const fs = require('fs');
let appJs = fs.readFileSync('app.js', 'utf8');

// 1. Add btn-add-schedule listeners to initializeUI if not present
if (!appJs.includes('btn-add-schedule')) {
    const listeners = `
    // Schedule Listeners
    document.getElementById("btn-add-schedule")?.addEventListener("click", () => {
        document.getElementById("form-schedule").reset();
        document.getElementById("schedule-id").value = "";
        document.getElementById("schedule-modal").classList.add("active");
    });
    document.getElementById("btn-close-schedule-modal")?.addEventListener("click", () => {
        document.getElementById("schedule-modal").classList.remove("active");
    });
    document.getElementById("btn-cancel-schedule")?.addEventListener("click", () => {
        document.getElementById("schedule-modal").classList.remove("active");
    });
    document.getElementById("form-schedule")?.addEventListener("submit", (e) => {
        e.preventDefault();
        saveSchedule();
    });
`;
    // Insert inside initializeUI, right after navItems.forEach
    const insertionPoint = `navItems.forEach(item => {
        item.addEventListener("click", () => {`;
    appJs = appJs.replace(insertionPoint, listeners + '\n    ' + insertionPoint);
}

// 2. Add WA buttons to renderAttendanceTab
if (!appJs.includes('href="https://wa.me')) {
    const waHtmlCode = `
        let waSakit = '';
        if (currentStatus === 'Sakit') {
            const waText = encodeURIComponent("Assalamualaikum, kami dari pengurus Kelompok Assalam mendoakan semoga lekas sembuh, selalu dalam lindungan Allah.");
            waSakit = \`<a href="https://wa.me/?text=\${waText}" target="_blank" class="btn-status" style="background:#25D366;color:white;min-width:40px;padding:8px" title="Doakan Sakit via WA"><i data-lucide="message-circle"></i></a>\`;
        }
        let waIzin = '';
        if (currentStatus === 'Ijin') {
            const waTextIzin = encodeURIComponent("Assalamualaikum, kami dari pengurus Kelompok Assalam sudah mencatat izin Bapak/Ibu untuk pengajian hari ini.");
            waIzin = \`<a href="https://wa.me/?text=\${waTextIzin}" target="_blank" class="btn-status" style="background:#25D366;color:white;min-width:40px;padding:8px" title="Balas Izin via WA"><i data-lucide="message-circle"></i></a>\`;
        }
`;

    // inject right before card.innerHTML = `
    appJs = appJs.replace('        const streak = calculateMemberStreak(m.id);\n        \n        card.innerHTML = `', waHtmlCode + '\n        const streak = calculateMemberStreak(m.id);\n        \n        card.innerHTML = `');

    // inject into the HTML string
    appJs = appJs.replace(
        '<div class="attendance-actions-group">',
        '<div class="attendance-actions-group">\n                ${waSakit}\n                ${waIzin}'
    );
}

fs.writeFileSync('app.js', appJs);
console.log('app.js fixed');
