const fs = require('fs');
let css = fs.readFileSync('style.css', 'utf8');

// Replacements for text color
const replaceWhite = [
    '.brand-text h1',
    '.nav-item:hover',
    '.stat-card-value',
    '.dashboard-section-title',
    '.prayer-time-name',
    '.form-input, .form-select, .form-textarea',
    '.stat-value',
    '.activity-name',
    '.empty-state h3',
    '.attendance-card-name',
    '.member-name-text',
    '.podium-name',
    '.modal-header h3'
];

replaceWhite.forEach(selector => {
    // regex to find the selector block and replace color: white; with color: var(--text-main);
    const escaped = selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escaped}\\s*{[^}]*)color:\\s*white;([^}]*})`, 'g');
    css = css.replace(regex, '$1color: var(--text-main);$2');
});

// nav-item.active
css = css.replace(/(\.nav-item\.active\s*{[^}]*)color:\s*white;([^}]*})/, '$1color: var(--color-primary);$2');

// Fix white semi-transparent backgrounds to dark semi-transparent for light mode
css = css.replace(/rgba\(255,\s*255,\s*255,\s*0\.03\)/g, 'rgba(0, 0, 0, 0.03)');
css = css.replace(/rgba\(255,\s*255,\s*255,\s*0\.05\)/g, 'rgba(0, 0, 0, 0.05)');
css = css.replace(/rgba\(255,\s*255,\s*255,\s*0\.08\)/g, 'rgba(0, 0, 0, 0.08)');
css = css.replace(/rgba\(255,\s*255,\s*255,\s*0\.1\)/g, 'rgba(0, 0, 0, 0.1)');
css = css.replace(/rgba\(255,\s*255,\s*255,\s*0\.15\)/g, 'rgba(0, 0, 0, 0.15)');
css = css.replace(/rgba\(255,\s*255,\s*255,\s*0\.2\)/g, 'rgba(0, 0, 0, 0.2)');

// Fix form input background which was dark
css = css.replace(/background:\s*rgba\(15,\s*23,\s*42,\s*0\.6\);/g, 'background: rgba(255, 255, 255, 0.9);');

fs.writeFileSync('style.css', css);
console.log('CSS fixed for light theme!');
