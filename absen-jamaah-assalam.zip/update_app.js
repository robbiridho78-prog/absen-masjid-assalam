const fs = require('fs');
let app = fs.readFileSync('app.js', 'utf8');

// 1. Add "Alpa" button
const oldActionsGroup = `            <div class="attendance-actions-group">
                <button class="btn-status btn-status-hadir \${currentStatus === 'Hadir' ? 'active' : ''}" onclick="setAttendanceStatus('\${m.id}', 'Hadir')" title="Tandai Hadir">
                    <i data-lucide="check-circle-2"></i> Hadir
                </button>
                <button class="btn-status btn-status-sakit \${currentStatus === 'Sakit' ? 'active' : ''}" onclick="setAttendanceStatus('\${m.id}', 'Sakit')" title="Tandai Sakit">
                    <i data-lucide="activity"></i> Sakit
                </button>
                <button class="btn-status btn-status-ijin \${currentStatus === 'Ijin' ? 'active' : ''}" onclick="setAttendanceStatus('\${m.id}', 'Ijin')" title="Tandai Ijin">
                    <i data-lucide="info"></i> Ijin
                </button>
            </div>`;

const newActionsGroup = `            <div class="attendance-actions-group">
                <button class="btn-status btn-status-hadir \${currentStatus === 'Hadir' ? 'active' : ''}" onclick="setAttendanceStatus('\${m.id}', 'Hadir')" title="Tandai Hadir">
                    <i data-lucide="check-circle-2"></i> Hadir
                </button>
                <button class="btn-status btn-status-sakit \${currentStatus === 'Sakit' ? 'active' : ''}" onclick="setAttendanceStatus('\${m.id}', 'Sakit')" title="Tandai Sakit">
                    <i data-lucide="thermometer"></i> Sakit
                </button>
                <button class="btn-status btn-status-ijin \${currentStatus === 'Ijin' ? 'active' : ''}" onclick="setAttendanceStatus('\${m.id}', 'Ijin')" title="Tandai Ijin">
                    <i data-lucide="info"></i> Izin
                </button>
                <button class="btn-status btn-status-alpa \${currentStatus === 'Alpa' ? 'active' : ''}" onclick="setAttendanceStatus('\${m.id}', 'Alpa')" title="Tandai Alpa">
                    <i data-lucide="x-circle"></i> Alpa
                </button>
            </div>`;

app = app.replace(oldActionsGroup, newActionsGroup);

// 2. Replace updateDashboard function completely
const oldUpdateDashboardStart = app.indexOf('function updateDashboard() {');
const oldUpdateDashboardEnd = app.indexOf('// 4. Active Streaks Count');

if (oldUpdateDashboardStart !== -1 && oldUpdateDashboardEnd !== -1) {
    const newDashboardLogic = `function updateDashboard() {
    // 1. Total Registered
    const totalJamaah = state.jamaah.length;
    document.getElementById("stat-total-jamaah").textContent = totalJamaah;
    
    // 2. Today's Stats
    const todayStr = new Date().toISOString().split('T')[0];
    const todayLogs = state.attendance.filter(log => log.date === todayStr);
    
    const countHadir = todayLogs.filter(log => log.status === "Hadir" || log.present).length;
    const countIzin = todayLogs.filter(log => log.status === "Ijin" || log.status === "Izin").length;
    const countSakit = todayLogs.filter(log => log.status === "Sakit").length;
    const countAlpa = todayLogs.filter(log => log.status === "Alpa").length;
    // Also consider those not marked as Alpa implicitly? No, just explicitly marked Alpa + implicitly unmarked
    const countBelumAbsen = totalJamaah - (countHadir + countIzin + countSakit + countAlpa);
    const totalAlpaReal = countAlpa + countBelumAbsen;
    
    const pctHadir = totalJamaah > 0 ? Math.round((countHadir / totalJamaah) * 100) : 0;
    const pctIzin = totalJamaah > 0 ? Math.round((countIzin / totalJamaah) * 100) : 0;
    const pctSakit = totalJamaah > 0 ? Math.round((countSakit / totalJamaah) * 100) : 0;
    const pctAlpa = totalJamaah > 0 ? Math.round((totalAlpaReal / totalJamaah) * 100) : 0;
    
    const elHadirPct = document.getElementById("stat-today-attendance");
    if(elHadirPct) elHadirPct.textContent = \`\${pctHadir}%\`;
    const elHadirCount = document.getElementById("stat-today-count");
    if(elHadirCount) elHadirCount.textContent = \`\${countHadir} Hadir\`;
    
    const elIzinCount = document.getElementById("stat-izin-count");
    if(elIzinCount) elIzinCount.textContent = countIzin;
    const elIzinPct = document.getElementById("stat-izin-pct");
    if(elIzinPct) elIzinPct.textContent = \`\${pctIzin}% dari total\`;
    
    const elSakitCount = document.getElementById("stat-sakit-count");
    if(elSakitCount) elSakitCount.textContent = countSakit;
    const elSakitPct = document.getElementById("stat-sakit-pct");
    if(elSakitPct) elSakitPct.textContent = \`\${pctSakit}% dari total\`;
    
    const elAlpaCount = document.getElementById("stat-alpa-count");
    if(elAlpaCount) elAlpaCount.textContent = totalAlpaReal;
    const elAlpaPct = document.getElementById("stat-alpa-pct");
    if(elAlpaPct) elAlpaPct.textContent = \`\${pctAlpa}% dari total\`;
    
    // 3. Average Attendance Senin & Kamis
    // Filter out only dates that are Monday (1) or Thursday (4)
    const uniqueDates = [...new Set(state.attendance.map(log => log.date))];
    const uniqueSeninKamis = uniqueDates.filter(d => {
        const day = new Date(d).getDay();
        return day === 1 || day === 4;
    });
    
    const last30SeninKamis = uniqueSeninKamis.slice(-30);
    let avgSeninKamisPct = 0;
    
    if (last30SeninKamis.length > 0 && totalJamaah > 0) {
        let sumPct = 0;
        last30SeninKamis.forEach(date => {
            const count = state.attendance.filter(log => log.date === date && (log.status === "Hadir" || log.present)).length;
            sumPct += (count / totalJamaah) * 100;
        });
        avgSeninKamisPct = Math.round(sumPct / last30SeninKamis.length);
    }
    const elAvgSeninKamis = document.getElementById("stat-avg-senin-kamis");
    if(elAvgSeninKamis) elAvgSeninKamis.textContent = \`\${avgSeninKamisPct}%\`;
    
    `;
    app = app.substring(0, oldUpdateDashboardStart) + newDashboardLogic + app.substring(oldUpdateDashboardEnd);
}

// 3. Let's fix setAttendanceStatus to handle toggle off
const setAttStart = app.indexOf('function setAttendanceStatus(');
const setAttEnd = app.indexOf('function handleFilterChange(');
if (setAttStart !== -1 && setAttEnd !== -1) {
    app = app.substring(0, setAttStart) + \`function setAttendanceStatus(memberId, status) {
    const today = document.getElementById("attendance-date").value;
    const existingIndex = state.attendance.findIndex(log => log.date === today && log.member_id === memberId);
    
    if (existingIndex >= 0) {
        if (state.attendance[existingIndex].status === status) {
            // Toggle off if clicking the same status
            state.attendance.splice(existingIndex, 1);
        } else {
            state.attendance[existingIndex].status = status;
            state.attendance[existingIndex].present = (status === 'Hadir');
        }
    } else {
        const newId = 'att-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
        state.attendance.push({
            id: newId,
            date: today,
            member_id: memberId,
            status: status,
            present: (status === 'Hadir'),
            created_at: new Date().toISOString()
        });
    }
    
    saveToLocalStorage();
    renderAttendanceTab();
    updateDashboard();
    
    // Upload implicitly
    if (window.db && window.db.upsertAttendance) {
        const currentLog = state.attendance.find(log => log.date === today && log.member_id === memberId);
        if (currentLog) {
            window.db.upsertAttendance(currentLog).catch(e => console.error(e));
        }
    }
}
\` + app.substring(setAttEnd);
}

fs.writeFileSync('app.js', app);
console.log('app.js updated successfully!');
