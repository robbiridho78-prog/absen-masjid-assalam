const fs = require('fs');

const SUPABASE_URL = 'https://jnknaljkszavgdntrfzu.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Impua25hbGprc3phdmdkbnRyZnp1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEyNTYyNzAsImV4cCI6MjA5NjgzMjI3MH0.koG3QgPMaFCGoPfgbOINRATs_yf2bHwb4EpuzFENdHY';

const headers = {
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
    'Content-Type': 'application/json',
    'Prefer': 'resolution=merge-duplicates'
};

async function uploadData() {
    console.log("Reading file...");
    const rawData = fs.readFileSync('C:/Users/USER/Downloads/database-absen-jamaah-2026-06-16 (1).json');
    const data = JSON.parse(rawData);
    
    if (!data.jamaah || data.jamaah.length === 0) {
        console.log("No jamaah data found!");
        return;
    }
    
    console.log(`Found ${data.jamaah.length} jamaah. Uploading...`);
    
    let successCount = 0;
    
    for (const member of data.jamaah) {
        try {
            const payload = {
                id: member.id,
                name: member.name,
                gender: member.gender || '-',
                category: member.category || '-',
                phone: member.phone || '',
                address: member.address || ''
            };
            
            const res = await fetch(`${SUPABASE_URL}/rest/v1/jamaah`, {
                method: 'POST',
                headers,
                body: JSON.stringify(payload)
            });
            
            if (res.ok) {
                successCount++;
                console.log(`Uploaded: ${member.name}`);
            } else {
                console.error(`Failed: ${member.name}`, await res.text());
            }
        } catch (err) {
            console.error(`Error on ${member.name}:`, err.message);
        }
    }
    
    console.log(`Finished! Successfully uploaded ${successCount} out of ${data.jamaah.length}`);
}

uploadData();
