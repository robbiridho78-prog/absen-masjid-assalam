const SUPABASE_URL = 'https://jnknaljkszavgdntrfzu.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Impua25hbGprc3phdmdkbnRyZnp1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEyNTYyNzAsImV4cCI6MjA5NjgzMjI3MH0.koG3QgPMaFCGoPfgbOINRATs_yf2bHwb4EpuzFENdHY';

async function testInsert() {
    const fetch = require('node-fetch');
    const response = await fetch(`${SUPABASE_URL}/rest/v1/jamaah`, {
        method: 'POST',
        headers: {
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify({
            id: 'test_123',
            name: 'Test',
            gender: 'Laki-laki',
            category: 'Dewasa',
            phone: '',
            address: ''
        })
    });
    const text = await response.text();
    console.log("Status:", response.status);
    console.log("Body:", text);
}
testInsert();
