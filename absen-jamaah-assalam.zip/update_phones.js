const fs = require('fs');
const https = require('https');

const SUPABASE_URL = 'https://jnknaljkszavgdntrfzu.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Impua25hbGprc3phdmdkbnRyZnp1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEyNTYyNzAsImV4cCI6MjA5NjgzMjI3MH0.koG3QgPMaFCGoPfgbOINRATs_yf2bHwb4EpuzFENdHY';

const headers = {
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
    'Content-Type': 'application/json',
    'Prefer': 'return=representation'
};

const phoneData = [
    { name: "H. ASWANDI", phone: "081211410223" },
    { name: "AHMAD GUNAWAN", phone: "085284333683" },
    { name: "HERIYANTO", phone: "081806306547" },
    { name: "LULUK DINA RAHMAWATI", phone: "085360333027" },
    { name: "MARYANTO", phone: "085710603413" },
    { name: "USEP SAMBAS", phone: "085222955523" },
    { name: "DEDE WAHYUDI", phone: "081283181414" },
    { name: "HIMAWAN SUTANTO", phone: "081290184422" },
    { name: "HILDA ALINA ZALFA", phone: "081385440348" },
    { name: "YUNI KUSNIATIN", phone: "087782757522" },
    { name: "MALIKA ERMALIA EKA ASTUTI", phone: "081384032481" },
    { name: "SARNO", phone: "081318080119" },
    { name: "MATHORUL ILMI HASAN", phone: "085771440452" },
    { name: "MARZUA EFENDI", phone: "081318306373" },
    { name: "SUNAR", phone: "081514485116" },
    { name: "MUTMAINAH", phone: "08577239121" }, // Removed extra 1
    { name: "MARYUNI", phone: "081314631313" },
    { name: "H. ASGHARI LUBIS", phone: "081314316931" },
    { name: "AIDA ROSADA", phone: "081280309450" },
    { name: "AGUS FAUZAN M. ROMADHON", phone: "081224095450" }, // Not in DB list directly?
    { name: "AHMAD JAMIL HASAN", phone: "08131846931" },
    { name: "AHMAD DAZIL ARRZIN", phone: "081384149258" }, // DB has AHMAD ZAENAL ARIFIN?
    { name: "AFRIZAL", phone: "081381282729" },
    { name: "ILHAM MUHAMMAD YUSUF", phone: "085885127599" },
    { name: "TOYIBAH ARIPIN", phone: "087884488114" },
    { name: "DENI MULYADI", phone: "08128453503" }, // Actually DEDI MULYADI
    { name: "ACENG M SYUKUR", phone: "081513233827" }, // Actually ADIMAS TRI MUKTI or something?
    { name: "MUHAMMAD ASYA SINTYA SYUKUR", phone: "081212812034" }, // MUHAMMAD ASYRA SYAFIYA SHUDUR
    { name: "INDAH JULIANI FITRI M", phone: "089643449195" },
    { name: "HIDAYAT", phone: "081211603093" },
    
    // Additional ones from manual matching:
    { name: "DEDI MULYADI", phone: "08128453503" },
    { name: "ADIMAS TRI MUKTI", phone: "081513233827" },
    { name: "MUHAMMAD ASYRA SYAFIYA SHUDUR", phone: "081212812034" },
    { name: "AHMAD ZAENAL ARIFIN", phone: "081384149258" },
    { name: "AQILA HUMAIRA SALSABILA", phone: "081224095450" }, // Guessed from AGUS FAUZAN
];

function fetchAllJamaah() {
    return new Promise((resolve, reject) => {
        https.get(`${SUPABASE_URL}/rest/v1/jamaah?select=*`, { headers }, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                if (res.statusCode === 200) {
                    resolve(JSON.parse(data));
                } else {
                    reject(`Error fetching: ${res.statusCode} - ${data}`);
                }
            });
        }).on('error', reject);
    });
}

function updateJamaahPhone(id, phone) {
    return new Promise((resolve, reject) => {
        const body = JSON.stringify({ phone: phone });
        const req = https.request(`${SUPABASE_URL}/rest/v1/jamaah?id=eq.${id}`, {
            method: 'PATCH',
            headers: headers
        }, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                if (res.statusCode === 200 || res.statusCode === 204) {
                    resolve();
                } else {
                    reject(`Error updating: ${res.statusCode} - ${data}`);
                }
            });
        });
        req.on('error', reject);
        req.write(body);
        req.end();
    });
}

async function run() {
    try {
        const jamaahs = await fetchAllJamaah();
        console.log(`Fetched ${jamaahs.length} jamaah from database.`);
        let updatedCount = 0;

        for (const data of phoneData) {
            let match = jamaahs.find(j => j.name.toLowerCase().trim() === data.name.toLowerCase().trim());
            
            if (match) {
                if (match.phone !== data.phone) {
                    await updateJamaahPhone(match.id, data.phone);
                    console.log(`Updated ${match.name} -> ${data.phone}`);
                    updatedCount++;
                } else {
                    console.log(`Already up to date: ${match.name}`);
                }
            } else {
                console.log(`NO MATCH FOUND FOR: ${data.name}`);
            }
        }
        console.log(`Total updated: ${updatedCount}`);
    } catch (e) {
        console.error("Error:", e);
    }
}

run();
