const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

const oldGridStart = html.indexOf('<div class="dashboard-grid">');
const oldGridEnd = html.indexOf('<div class="dashboard-grid full-width">');

if (oldGridStart !== -1 && oldGridEnd !== -1) {
    const newGrid = `<div class="dashboard-grid">
                    <!-- Card 1: Total Jamaah -->
                    <div class="stat-card">
                        <div class="stat-icon-wrapper emerald">
                            <i data-lucide="users"></i>
                        </div>
                        <div class="stat-data">
                            <span class="stat-label">Total Jamaah</span>
                            <h3 class="stat-value" id="stat-total-jamaah">0</h3>
                            <span class="stat-trend green"><i data-lucide="trending-up"></i> Terdaftar</span>
                        </div>
                    </div>
                    
                    <!-- Card 2: Kehadiran Hari Ini -->
                    <div class="stat-card">
                        <div class="stat-icon-wrapper amber">
                            <i data-lucide="calendar-check"></i>
                        </div>
                        <div class="stat-data">
                            <span class="stat-label">Hadir Hari Ini</span>
                            <h3 class="stat-value" id="stat-today-attendance">0%</h3>
                            <span class="stat-trend amber" id="stat-today-count">0 Hadir</span>
                        </div>
                    </div>
                    
                    <!-- Card 3: Izin -->
                    <div class="stat-card">
                        <div class="stat-icon-wrapper blue">
                            <i data-lucide="info"></i>
                        </div>
                        <div class="stat-data">
                            <span class="stat-label">Izin Hari Ini</span>
                            <h3 class="stat-value" id="stat-izin-count">0</h3>
                            <span class="stat-trend blue" id="stat-izin-pct">0% dari total</span>
                        </div>
                    </div>
                    
                    <!-- Card 4: Sakit -->
                    <div class="stat-card">
                        <div class="stat-icon-wrapper purple">
                            <i data-lucide="thermometer"></i>
                        </div>
                        <div class="stat-data">
                            <span class="stat-label">Sakit Hari Ini</span>
                            <h3 class="stat-value" id="stat-sakit-count">0</h3>
                            <span class="stat-trend purple" id="stat-sakit-pct">0% dari total</span>
                        </div>
                    </div>

                    <!-- Card 5: Tidak Hadir (Alpa) -->
                    <div class="stat-card">
                        <div class="stat-icon-wrapper" style="background: rgba(239, 68, 68, 0.1); color: #ef4444;">
                            <i data-lucide="user-x"></i>
                        </div>
                        <div class="stat-data">
                            <span class="stat-label">Tidak Hadir (Alpa)</span>
                            <h3 class="stat-value" id="stat-alpa-count">0</h3>
                            <span class="stat-trend red" style="color: #ef4444;" id="stat-alpa-pct">0% dari total</span>
                        </div>
                    </div>

                    <!-- Card 6: Rata-rata Senin & Kamis -->
                    <div class="stat-card">
                        <div class="stat-icon-wrapper" style="background: rgba(16, 185, 129, 0.1); color: #10b981;">
                            <i data-lucide="bar-chart-2"></i>
                        </div>
                        <div class="stat-data">
                            <span class="stat-label">Rata-rata Senin & Kamis</span>
                            <h3 class="stat-value" id="stat-avg-senin-kamis">0%</h3>
                            <span class="stat-trend green">30 Hari Terakhir</span>
                        </div>
                    </div>
                </div>
                
                `;
                
    html = html.substring(0, oldGridStart) + newGrid + html.substring(oldGridEnd);
    fs.writeFileSync('index.html', html);
    console.log("Dashboard cards updated in index.html");
} else {
    console.log("Could not find the grid boundaries.");
}
