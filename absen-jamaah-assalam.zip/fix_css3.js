const fs = require('fs');
let css = fs.readFileSync('style.css', 'utf8');

// Update to premium bright theme
css = css.replace(/--bg-primary:\s*[^;]+;/, '--bg-primary: #f0f4f8;');
css = css.replace(/--bg-secondary:\s*[^;]+;/, '--bg-secondary: #ffffff;');
css = css.replace(/--bg-card:\s*[^;]+;/, '--bg-card: #ffffff;');
css = css.replace(/--bg-card-hover:\s*[^;]+;/, '--bg-card-hover: #f8fafc;');
css = css.replace(/--border-color:\s*[^;]+;/, '--border-color: rgba(0, 0, 0, 0.08);');
css = css.replace(/--border-color-hover:\s*[^;]+;/, '--border-color-hover: rgba(59, 130, 246, 0.4);');

// Fix text colors to be sharp
css = css.replace(/--text-main:\s*[^;]+;/, '--text-main: #0f172a;');
css = css.replace(/--text-muted:\s*[^;]+;/, '--text-muted: #64748b;');

// Fix mobile bottom nav background
css = css.replace(/background:\s*rgba\(9,\s*13,\s*22,\s*0\.95\);/g, 'background: rgba(255, 255, 255, 0.95);');

// Fix modal background
css = css.replace(/background-color:\s*rgba\(9,\s*13,\s*22,\s*0\.8\);/g, 'background-color: rgba(0, 0, 0, 0.5);');

// Fix sidebar footer time widget
css = css.replace(/background:\s*rgba\(0,\s*0,\s*0,\s*0\.02\);/, 'background: #f8fafc;');

fs.writeFileSync('style.css', css);
console.log('CSS fixed for premium bright theme!');
