const fs = require('fs');
let appJs = fs.readFileSync('app.js', 'utf8');

// The string we previously injected for WA Sakit:
const oldWaSakit = 'waSakit = `<a href="https://wa.me/?text=${waText}"';
const newWaSakit = `
            let phoneStr = m.phone ? m.phone.replace(/[^0-9]/g, '') : '';
            if (phoneStr.startsWith('0')) phoneStr = '62' + phoneStr.slice(1);
            const waUrlSakit = phoneStr ? \`https://wa.me/\${phoneStr}?text=\${waText}\` : \`https://wa.me/?text=\${waText}\`;
            waSakit = \`<a href="\${waUrlSakit}"\`;
`;

// The string for WA Izin:
const oldWaIzin = 'waIzin = `<a href="https://wa.me/?text=${waTextIzin}"';
const newWaIzin = `
            let phoneStrIzin = m.phone ? m.phone.replace(/[^0-9]/g, '') : '';
            if (phoneStrIzin.startsWith('0')) phoneStrIzin = '62' + phoneStrIzin.slice(1);
            const waUrlIzin = phoneStrIzin ? \`https://wa.me/\${phoneStrIzin}?text=\${waTextIzin}\` : \`https://wa.me/?text=\${waTextIzin}\`;
            waIzin = \`<a href="\${waUrlIzin}"\`;
`;

appJs = appJs.replace(oldWaSakit, newWaSakit.trim());
appJs = appJs.replace(oldWaIzin, newWaIzin.trim());

fs.writeFileSync('app.js', appJs);
console.log('app.js updated with phone numbers');
