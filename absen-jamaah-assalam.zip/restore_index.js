const fs = require('fs');

const logPath = 'C:\\Users\\USER\\.gemini\\antigravity-ide\\brain\\12d2e9c8-6472-41e4-a428-f78e9d908179\\.system_generated\\logs\\transcript_full.jsonl';
const lines = fs.readFileSync(logPath, 'utf8').split('\n');

let diffBlock = '';
let capturing = false;

// We look for the last USER_INPUT that has the diff block
for (let i = lines.length - 1; i >= 0; i--) {
    if (lines[i].includes('The following changes were made by the USER to:')) {
        const obj = JSON.parse(lines[i]);
        const content = obj.content;
        const startIdx = content.indexOf('[diff_block_start]');
        const endIdx = content.indexOf('[diff_block_end]');
        if (startIdx !== -1 && endIdx !== -1) {
            diffBlock = content.substring(startIdx, endIdx);
            break;
        }
    }
}

if (!diffBlock) {
    console.log("Diff block not found!");
    process.exit(1);
}

// Parse the diff block and extract the deleted lines
let restoredLines = [];
const diffLines = diffBlock.split('\n');
for (const line of diffLines) {
    if (line.startsWith('-') && !line.startsWith('---')) {
        restoredLines.push(line.substring(1)); // remove the '-'
    }
}

// Now we need to insert these restored lines back into index.html
let indexHtml = fs.readFileSync('index.html', 'utf8');

// The user replaced from:
//                 <div class="form-group-vertical">
// to:
//                         <label>Materi Kajian & Pengajar (Maks 3)</label>
//
// Let's just find the exact spot.
// In the broken index.html, it has:
//             <form id="form-login">
//                 <div class="form-group-vertical">
//                         <label>Materi Kajian & Pengajar (Maks 3)</label>

const brokenString = `            <form id="form-login">
                <div class="form-group-vertical">
                        <label>Materi Kajian & Pengajar (Maks 3)</label>`;

const restoredString = `            <form id="form-login">
                <div class="form-group-vertical">
` + restoredLines.join('\n') + `
                        <label>Materi Kajian & Pengajar (Maks 3)</label>`;

if (indexHtml.includes(brokenString)) {
    indexHtml = indexHtml.replace(brokenString, restoredString);
    // Also fix the schedule modal which got messed up by the user pasting over it
    // Wait, the user deleted EVERYTHING between form-login and schedule modal.
    // The schedule modal IS in the restored lines!
    // But wait, the user's paste INCLUDED the new schedule modal inside form-login.
    // Let's just replace the whole file using the reconstructed version.
}

// ACTUALLY, let's just reconstruct it manually from the diff.
// The diff shows exactly what was removed.
let finalHtml = fs.readFileSync('index.html', 'utf8');
const linesOfBroken = finalHtml.split('\n');

const formLoginIdx = linesOfBroken.findIndex(l => l.includes('<form id="form-login">'));
if (formLoginIdx !== -1) {
    // lines before the deletion
    const before = linesOfBroken.slice(0, formLoginIdx + 2).join('\n');
    
    // the deleted content
    const deleted = restoredLines.join('\n');
    
    // the rest of the broken file (which contains the new modal fields they pasted)
    const after = linesOfBroken.slice(formLoginIdx + 2).join('\n');
    
    fs.writeFileSync('index.html_restored', before + '\n' + deleted + '\n' + after);
    console.log("Restored index.html saved to index.html_restored");
}

