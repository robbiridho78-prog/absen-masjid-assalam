const fs = require('fs');

const logPath = 'C:\\Users\\USER\\.gemini\\antigravity-ide\\brain\\12d2e9c8-6472-41e4-a428-f78e9d908179\\.system_generated\\logs\\transcript_full.jsonl';
const lines = fs.readFileSync(logPath, 'utf8').split('\n');

for (let i = lines.length - 1; i >= 0; i--) {
    if (lines[i].includes('The following changes were made by the USER to: c:\\\\Users\\\\USER\\\\.gemini\\\\antigravity\\\\scratch\\\\absen-jamaah-assalam\\\\index.html')) {
        try {
            const obj = JSON.parse(lines[i]);
            fs.writeFileSync('diff_block.txt', obj.content);
            console.log('Saved to diff_block.txt');
            process.exit(0);
        } catch (e) {
            console.error(e);
        }
    }
}
console.log('Not found');
