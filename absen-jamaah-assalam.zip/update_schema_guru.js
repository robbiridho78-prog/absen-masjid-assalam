const fs = require('fs');

// 1. Update index.html
let html = fs.readFileSync('index.html', 'utf8');
const oldFormHtml = `<div class="form-group-vertical">
                        <label for="schedule-teacher">Nama Guru / Ustadz</label>
                        <input type="text" id="schedule-teacher" class="form-input" placeholder="Contoh: Ustadz Fulan" required>
                    </div>
                    <div class="form-group-vertical">
                        <label>Materi Kajian (Maks 3)</label>
                        <input type="text" id="schedule-materi-1" class="form-input mb-2" placeholder="1. Materi Pertama" required>
                        <input type="text" id="schedule-materi-2" class="form-input mb-2" placeholder="2. Materi Kedua (Opsional)">
                        <input type="text" id="schedule-materi-3" class="form-input" placeholder="3. Materi Ketiga (Opsional)">
                    </div>`;

const newFormHtml = `<div class="form-group-vertical">
                        <label>Materi Kajian & Pengajar (Maks 3)</label>
                        <div style="display:flex; gap:8px; margin-bottom:8px;">
                            <input type="text" id="schedule-materi-1" class="form-input" placeholder="1. Materi Pertama" required style="flex:2;">
                            <input type="text" id="schedule-guru-1" class="form-input" placeholder="Pengajar" required style="flex:1;">
                        </div>
                        <div style="display:flex; gap:8px; margin-bottom:8px;">
                            <input type="text" id="schedule-materi-2" class="form-input" placeholder="2. Materi Kedua (Opsional)" style="flex:2;">
                            <input type="text" id="schedule-guru-2" class="form-input" placeholder="Pengajar" style="flex:1;">
                        </div>
                        <div style="display:flex; gap:8px; margin-bottom:8px;">
                            <input type="text" id="schedule-materi-3" class="form-input" placeholder="3. Materi Ketiga (Opsional)" style="flex:2;">
                            <input type="text" id="schedule-guru-3" class="form-input" placeholder="Pengajar" style="flex:1;">
                        </div>
                    </div>`;

if (html.includes('id="schedule-teacher"')) {
    // Regex or string replace might be tricky due to whitespace, let's use regex
    const regex = /<div class="form-group-vertical">[\s\S]*?schedule-teacher[\s\S]*?<\/div>[\s\S]*?<div class="form-group-vertical">[\s\S]*?schedule-materi-1[\s\S]*?<\/div>/;
    html = html.replace(regex, newFormHtml);
    html = html.replace(/app\.js\?v=36/g, 'app.js?v=37');
    fs.writeFileSync('index.html', html);
    console.log('index.html updated.');
} else {
    console.log('Could not find form html in index.html');
}

// 2. Update app.js
let appjs = fs.readFileSync('app.js', 'utf8');

const saveSchRegex = /function saveSchedule\(\) \{[\s\S]*?const materi3 = document\.getElementById\("schedule-materi-3"\)\.value;/;
const newSaveSch = `function saveSchedule() {
    const id = document.getElementById("schedule-id").value;
    const date = document.getElementById("schedule-date").value;
    const time = document.getElementById("schedule-time").value;
    const materi1 = document.getElementById("schedule-materi-1").value;
    const guru1 = document.getElementById("schedule-guru-1").value;
    const materi2 = document.getElementById("schedule-materi-2").value;
    const guru2 = document.getElementById("schedule-guru-2").value;
    const materi3 = document.getElementById("schedule-materi-3").value;
    const guru3 = document.getElementById("schedule-guru-3").value;`;
appjs = appjs.replace(saveSchRegex, newSaveSch);

appjs = appjs.replace(
    'state.schedules[index] = { id, date, time, teacher, materi1, materi2, materi3 };',
    'state.schedules[index] = { id, date, time, materi1, guru1, materi2, guru2, materi3, guru3 };'
);
appjs = appjs.replace(
    'state.schedules.push({ id: newId, date, time, teacher, materi1, materi2, materi3 });',
    'state.schedules.push({ id: newId, date, time, materi1, guru1, materi2, guru2, materi3, guru3 });'
);

const renderMateriHtmlRegex = /let materiHtml = '';[\s\S]*?if \(sch\.materi3\) materiHtml \+= \`<li>\$\{sch\.materi3\}<\/li>\`;/;
const newMateriHtml = `let materiHtml = '';
        if (sch.materi1) materiHtml += \`<li style="margin-bottom:6px;"><strong>\${sch.materi1}</strong><br><span style="color:var(--text-muted); font-size:0.8rem;"><i data-lucide="user" style="width:12px; height:12px; vertical-align:middle; margin-right:4px;"></i>\${sch.guru1 || 'Pengurus'}</span></li>\`;
        if (sch.materi2) materiHtml += \`<li style="margin-bottom:6px;"><strong>\${sch.materi2}</strong><br><span style="color:var(--text-muted); font-size:0.8rem;"><i data-lucide="user" style="width:12px; height:12px; vertical-align:middle; margin-right:4px;"></i>\${sch.guru2 || 'Pengurus'}</span></li>\`;
        if (sch.materi3) materiHtml += \`<li style="margin-bottom:6px;"><strong>\${sch.materi3}</strong><br><span style="color:var(--text-muted); font-size:0.8rem;"><i data-lucide="user" style="width:12px; height:12px; vertical-align:middle; margin-right:4px;"></i>\${sch.guru3 || 'Pengurus'}</span></li>\`;`;
appjs = appjs.replace(renderMateriHtmlRegex, newMateriHtml);

// Remove the global teacher display
const teacherDisplayRegex = /<div class="flex-row align-center mb-4 text-muted">[\s\S]*?<strong>\$\{sch\.teacher\}<\/strong>[\s\S]*?<\/div>/;
appjs = appjs.replace(teacherDisplayRegex, '');
appjs = appjs.replace('Materi Kajian:', 'Agenda Kajian:');

fs.writeFileSync('app.js', appjs);
console.log('app.js updated.');
