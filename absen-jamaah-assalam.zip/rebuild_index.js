const fs = require('fs');

const diffBlockStr = fs.readFileSync('diff_block.txt', 'utf8');

const startIdx = diffBlockStr.indexOf('[diff_block_start]');
const endIdx = diffBlockStr.indexOf('[diff_block_end]');
if (startIdx === -1 || endIdx === -1) {
    console.error('Diff block markers not found');
    process.exit(1);
}

const diffContent = diffBlockStr.substring(startIdx + '[diff_block_start]'.length, endIdx).trim();
const lines = diffContent.split('\n');

let restoredLines = [];
let isCapturingDeleted = false;

// We skip the @@ header
for (const line of lines) {
    if (line.startsWith('@@')) continue;
    
    if (line.startsWith('-')) {
        restoredLines.push(line.substring(1)); // Remove the leading '-'
    } else if (line.startsWith(' ') && restoredLines.length > 0) {
        // Unchanged line
        // We only care about the deleted lines. 
        // We don't want to capture unchanged lines if they are not part of the deletion block
    }
}

console.log("Restored lines count: " + restoredLines.length);

// Now we rebuild the index.html from scratch using our memory + the restored lines + the new modal
// Let's read the current broken index.html
const brokenHtml = fs.readFileSync('index.html', 'utf8');
const brokenLines = brokenHtml.split('\n');

// Find the insertion point in the broken HTML
// The user replaced everything between `<form id="form-login">` and `<div class="form-group-vertical">`
// Wait, the diff shows:
//             <form id="form-login">
//                 <div class="form-group-vertical">
// - ...
// +                        <label>Materi Kajian & Pengajar (Maks 3)</label>

let finalHtml = '';
let replaced = false;

for (let i = 0; i < brokenLines.length; i++) {
    const line = brokenLines[i];
    finalHtml += line + '\n';
    
    if (line.includes('<form id="form-login">') && !replaced) {
        // We output the `<div class="form-group-vertical">`
        i++;
        finalHtml += brokenLines[i] + '\n';
        
        // NOW WE INJECT THE RESTORED LINES
        finalHtml += restoredLines.join('\n') + '\n';
        
        // Now we need to append the user's NEW pasted modal content.
        // In the broken file, the next line is `<label>Materi Kajian & Pengajar (Maks 3)</label>`
        // Let's just let the rest of the broken file append naturally.
        replaced = true;
    }
}

fs.writeFileSync('index.html', finalHtml);
console.log('Successfully restored index.html!');
