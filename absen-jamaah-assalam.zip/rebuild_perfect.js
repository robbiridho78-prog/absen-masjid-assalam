const fs = require('fs');

const diffBlockStr = fs.readFileSync('diff_block.txt', 'utf8');

const startIdx = diffBlockStr.indexOf('[diff_block_start]');
const endIdx = diffBlockStr.indexOf('[diff_block_end]');

const diffContent = diffBlockStr.substring(startIdx + '[diff_block_start]'.length, endIdx).trim();
const lines = diffContent.split('\n');

let restoredLines = [];

for (const line of lines) {
    if (line.startsWith('@@')) continue;
    if (line.startsWith('-')) {
        restoredLines.push(line.substring(1)); // Remove '-'
    }
}

let restoredHtml = restoredLines.join('\n');

// 1. Add Export CSV Button to Leaderboard
const exportBtnHtml = `
                <div class="flex-row justify-between align-center mb-4">
                    <h3 style="margin: 0;">Peringkat Jamaah Paling Istiqamah</h3>
                    <button id="btn-export-csv" class="btn btn-primary btn-sm admin-only">
                        <i data-lucide="download"></i> Download CSV
                    </button>
                </div>
`;
restoredHtml = restoredHtml.replace('<!-- Podiums for Top 3 Streaks -->', exportBtnHtml + '                <!-- Podiums for Top 3 Streaks -->');

// 2. Add Jadwal Pengajian to Sidebar
const scheduleNavHtml = `
                <button class="nav-item" data-tab="schedule" id="nav-schedule">
                    <i data-lucide="calendar"></i>
                    <span>Jadwal Pengajian</span>
                </button>`;
restoredHtml = restoredHtml.replace('                <button class="nav-item" data-tab="settings" id="nav-settings">', scheduleNavHtml + '\n                <button class="nav-item" data-tab="settings" id="nav-settings">');

// 3. Add Jadwal Pengajian Tab Content
const scheduleTabHtml = `
            <!-- TAB: Jadwal Pengajian -->
            <section id="tab-schedule" class="tab-panel">
                <div class="flex-row justify-between align-center mb-4">
                    <h2 class="section-title" style="margin: 0;">Jadwal Pengajian</h2>
                    <button id="btn-add-schedule" class="btn btn-primary admin-only">
                        <i data-lucide="plus"></i> Tambah Jadwal
                    </button>
                </div>
                
                <div id="schedule-list" class="schedule-grid">
                    <!-- Schedule cards will be rendered here -->
                </div>
            </section>
`;
const leaderboardEnd = '</section>\n\n            <!-- TAB 5: Settings -->';
restoredHtml = restoredHtml.replace(leaderboardEnd, '</section>\n\n' + scheduleTabHtml + '\n            <!-- TAB 5: Settings -->');

// Now we need the base of index.html.
const topHtml = `<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Absen Jamaah - Kelompok Assalam</title>
    <!-- Google Fonts: Outfit for Headings, Inter for Body -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Lucide Icons for premium visual design -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <!-- Chart.js for premium analytical dashboard -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="style.css?v=17">
    
    <!-- PWA Settings -->
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#e0f2fe">
    <link rel="apple-touch-icon" href="logo.jpg">
</head>
<body>
    <!-- LOGIN SCREEN -->
    <div id="login-screen" class="login-overlay active">
        <div class="login-card">
            <div class="login-header">
                <img src="logo.jpg" alt="Logo Assalam" class="login-logo">
                <h2 style="font-family: 'Times New Roman', Times, serif;">Selamat Datang</h2>
                <p>Aplikasi Absensi Kelompok Assalam</p>
            </div>
            <form id="form-login">
                <div class="form-group-vertical">`;

const bottomHtml = `
    <!-- Schedule Modal -->
    <div id="schedule-modal" class="modal-overlay">
        <div class="modal-card">
            <div class="modal-header">
                <h3 id="schedule-modal-title">Tambah Jadwal Baru</h3>
                <button class="btn-icon" id="btn-close-schedule-modal">
                    <i data-lucide="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <form id="form-schedule">
                    <input type="hidden" id="schedule-id">
                    <div class="form-group-vertical">
                        <label for="schedule-date">Tanggal</label>
                        <input type="date" id="schedule-date" class="form-input" required>
                    </div>
                    <div class="form-group-vertical">
                        <label for="schedule-time">Waktu / Jam</label>
                        <input type="time" id="schedule-time" class="form-input" required>
                    </div>
                    <div class="form-group-vertical">
                        <label>Materi Kajian & Pengajar (Maks 3)</label>
                        <div style="display:flex; gap:8px; margin-bottom:8px;">
                            <input type="text" id="schedule-materi-1" class="form-input" placeholder="1. Materi Pertama" required style="flex:2;">
                            <input type="text" id="schedule-guru-1" class="form-input" placeholder="Pengajar" required style="flex:1;">
                        </div>
                        <div style="display:flex; gap:8px; margin-bottom:8px;">
                            <input type="text" id="schedule-materi-2" class="form-input" placeholder="2. Materi Kedua (Opsional)" style="flex:2;">
                            <input type="text" id="schedule-guru-2" class="form-input" placeholder="Pengajar" style="flex:1;">
                        </div>
                        <div style="display:flex; gap:8px; margin-bottom:8px;">
                            <input type="text" id="schedule-materi-3" class="form-input" placeholder="3. Materi Ketiga (Opsional)" style="flex:2;">
                            <input type="text" id="schedule-guru-3" class="form-input" placeholder="Pengajar" style="flex:1;">
                        </div>
                    </div>
                    <div class="modal-actions mt-4">
                        <button type="button" class="btn btn-outline" id="btn-cancel-schedule">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Jadwal</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Supabase SDK & Client -->
    <script src="supabase-client.js"></script>

    <script src="app.js?v=42" defer></script>

    <!-- PWA Service Worker Registration -->
    <script>
      if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
          navigator.serviceWorker.register('sw.js').then(registration => {
            console.log('SW registered: ', registration);
          }).catch(registrationError => {
            console.log('SW registration failed: ', registrationError);
          });
        });
      }
    </script>
</body>
</html>`;

const finalHtml = topHtml + '\n' + restoredHtml + '\n' + bottomHtml;
fs.writeFileSync('index.html', finalHtml);
console.log('Rebuilt perfectly with all features!');
