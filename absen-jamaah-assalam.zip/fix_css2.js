const fs = require('fs');
let css = fs.readFileSync('style.css', 'utf8');

// Change root variables to Blue theme
css = css.replace(/--bg-primary:\s*#f0fdf4;/, '--bg-primary: #eff6ff;');
css = css.replace(/--bg-secondary:\s*#dcfce7;/, '--bg-secondary: #dbeafe;');
css = css.replace(/--border-color:\s*rgba\(34,\s*197,\s*94,\s*0\.2\);/, '--border-color: rgba(59, 130, 246, 0.2);');
css = css.replace(/--border-color-hover:\s*rgba\(22,\s*163,\s*74,\s*0\.5\);/, '--border-color-hover: rgba(37, 99, 235, 0.5);');

// Change text-main to pure black for maximum readability as requested
css = css.replace(/--text-main:\s*#0f172a;/, '--text-main: #000000;');
css = css.replace(/--text-muted:\s*#475569;/, '--text-muted: #1e293b;');

// Fix btn-secondary text color
css = css.replace(/(\.btn-secondary\s*{[^}]*)color:\s*white;([^}]*})/, '$1color: var(--text-main);$2');

// Fix form input color explicitly
css = css.replace(/(\.form-input,\s*\.form-select,\s*\.form-textarea\s*{[^}]*)color:\s*var\(--text-main\);([^}]*})/, '$1color: black;$2');

// Fix placeholders
const placeholderFix = `
.form-input::placeholder, .form-textarea::placeholder {
    color: rgba(0, 0, 0, 0.5);
}
`;
if (!css.includes('::placeholder')) {
    css += placeholderFix;
}

fs.writeFileSync('style.css', css);
console.log('CSS fixed for blue theme!');
