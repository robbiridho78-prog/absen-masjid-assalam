const fs = require('fs');
let css = fs.readFileSync('style.css', 'utf8');

// The original 1024px block
const old1024 = `
@media (max-width: 1024px) {
    .app-container {
        flex-direction: column;
    }
    
    .sidebar {
        width: 100%;
        height: auto;
        padding: 1rem 1.5rem;
        border-right: none;
        border-bottom: 1px solid var(--border-color);
        position: relative;
    }
    
    .sidebar-brand {
        margin-bottom: 1.5rem;
    }
    
    .sidebar-nav {
        flex-direction: row;
        flex-wrap: wrap;
        gap: 0.25rem;
    }
    
    .nav-item {
        padding: 0.6rem 0.85rem;
        font-size: 0.85rem;
    }
    
    .nav-item.active {
        border-left: none;
        border-bottom: 3px solid var(--color-primary);
        padding-left: 0.85rem;
        padding-bottom: calc(0.6rem - 3px);
    }
    
    .sidebar-footer {
        display: none;
    }
    
    .main-content {
        padding: 1.5rem;
        height: auto;
    }
    
    .dashboard-grid {
        grid-template-columns: 1fr;
    }
}`;

// Remove the old 1024px block
css = css.replace(old1024.trim(), '');

// Change the 640px block to 1024px
css = css.replace('@media (max-width: 640px)', '@media (max-width: 1024px)');

// Fix the bottom shadow which was dark, let's make it lighter
css = css.replace('box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.5);', 'box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.1);');

fs.writeFileSync('style.css', css);
console.log('Mobile navigation fixed to apply to all screens under 1024px!');
