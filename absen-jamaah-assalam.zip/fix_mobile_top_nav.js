const fs = require('fs');
let css = fs.readFileSync('style.css', 'utf8');

// The new perfect top-nav block
const newMediaBlock = `
@media (max-width: 1024px) {
    .app-container {
        flex-direction: column;
    }
    
    .sidebar {
        width: 100%;
        height: auto;
        padding: 1rem;
        position: relative;
        border-right: none;
        border-bottom: 1px solid var(--border-color);
        background: var(--bg-secondary);
        z-index: 100;
    }
    
    .sidebar-brand {
        display: flex;
        justify-content: center;
        margin-bottom: 1rem;
    }
    
    .sidebar-nav {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: center;
        gap: 0.5rem;
    }

    .nav-item {
        padding: 0.5rem 0.8rem;
        font-size: 0.85rem;
        border: none !important;
        background: transparent;
        flex-direction: row;
    }

    .nav-item.active {
        color: var(--color-primary);
        font-weight: bold;
        background: rgba(59, 130, 246, 0.1) !important;
        border-radius: var(--radius-sm);
    }
    
    .sidebar-divider {
        width: 100%;
        height: 1px;
        background: var(--border-color);
        margin: 0.5rem 0;
        display: block !important;
    }

    #btn-logout {
        display: flex !important;
        width: 100%;
        justify-content: center;
        background: #fee2e2;
        color: #ef4444 !important;
        border-radius: var(--radius-md);
        padding: 0.75rem;
        margin-top: 0.25rem;
        font-weight: bold;
    }

    .sidebar-footer {
        display: none !important;
    }
    
    .btn-mobile-logout {
        display: none !important;
    }

    .content-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 0.5rem;
        padding: 1rem;
    }

    .jamaah-attendance-grid {
        grid-template-columns: 1fr;
        gap: 0.75rem;
    }

    .filter-bar {
        flex-direction: column;
        align-items: stretch;
    }
    
    .filter-group, .search-box-wrapper, .filter-actions {
        width: 100%;
    }

    .data-table th, .data-table td {
        padding: 0.75rem 1rem;
        font-size: 0.85rem;
        white-space: nowrap;
    }
    
    .podium-container {
        gap: 0.5rem;
        height: 240px;
        padding-top: 2rem;
    }
    
    .podium-spot {
        width: 90px;
    }
    
    .podium-avatar {
        width: 45px;
        height: 45px;
    }

    .login-card {
        padding: 1.5rem;
        width: 90%;
    }
}
`;

// Replace everything from @media (max-width: 1024px) to the end of the file with the new block
const startIndex = css.indexOf('@media (max-width: 1024px)');
if (startIndex !== -1) {
    css = css.substring(0, startIndex) + newMediaBlock;
} else {
    css += newMediaBlock;
}

fs.writeFileSync('style.css', css);
console.log('Mobile navigation fixed to perfect top menu!');
