const SUPABASE_URL = 'https://jnknaljkszavgdntrfzu.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Impua25hbGprc3phdmdkbnRyZnp1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEyNTYyNzAsImV4cCI6MjA5NjgzMjI3MH0.koG3QgPMaFCGoPfgbOINRATs_yf2bHwb4EpuzFENdHY';

async function testSupabase() {
    console.log("Fetching from Supabase...");
    const fetch = require('node-fetch');
    const response = await fetch(`${SUPABASE_URL}/rest/v1/jamaah?select=*`, {
        headers: {
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
        }
    });
    const text = await response.text();
    console.log("Status:", response.status);
    console.log("Body:", text);
}

testSupabase();
