const fs = require('fs');

let app = fs.readFileSync('app.js', 'utf8');

const oldStr = app.substring(app.indexOf('let waSakit ='), app.indexOf('const streak = calculateMemberStreak(m.id);'));

const newStr = `let waButtonHtml = '';
        let phoneStr = m.phone ? m.phone.replace(/[^0-9]/g, '') : '';
        if (phoneStr) {
            if (phoneStr.startsWith('0')) phoneStr = '62' + phoneStr.slice(1);
            let waText = '';
            if (currentStatus === 'Sakit') {
                waText = encodeURIComponent("Assalamualaikum, kami dari pengurus Kelompok Assalam mendoakan semoga lekas sembuh, selalu dalam lindungan Allah.");
            } else if (currentStatus === 'Ijin') {
                waText = encodeURIComponent("Assalamualaikum, kami dari pengurus Kelompok Assalam sudah mencatat izin Bapak/Ibu untuk pengajian hari ini.");
            } else if (currentStatus === 'Alpa') {
                waText = encodeURIComponent("Assalamualaikum, kami perhatikan Bapak/Ibu belum bisa hadir di pengajian hari ini, semoga sehat selalu.");
            } else {
                waText = encodeURIComponent("Assalamualaikum, salam silaturahmi dari pengurus Kelompok Assalam.");
            }
            const waUrl = \`https://wa.me/\${phoneStr}?text=\${waText}\`;
            waButtonHtml = \`<a href="\${waUrl}" target="_blank" class="btn-status" style="background:#25D366;color:white;min-width:40px;padding:8px" title="Chat via WA"><i data-lucide="message-circle"></i></a>\`;
        }

        `;

app = app.replace(oldStr, newStr);

const oldActions = `\${waSakit}
                \${waIzin}`;
app = app.replace(oldActions, `\${waButtonHtml}`);

fs.writeFileSync('app.js', app);
console.log("Successfully patched app.js");
